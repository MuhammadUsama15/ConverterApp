//
//  SignUpVC.swift
//  UnitConverter
//
//  Created by Macbook Air on 2/7/21.
//  Copyright © 2021 tutorial. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

@available(iOS 13.0, *)
@available(iOS 13.0, *)
class SignUpVC: UIViewController {

    @IBOutlet weak var firstNameField: UITextField! {
        didSet {
            let whitePlaceholderText = NSAttributedString(string: "Enter first name", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
                    
                    firstNameField.attributedPlaceholder = whitePlaceholderText
        }
    }
    
    @IBOutlet weak var lastNameField: UITextField! {
        didSet {
            let whitePlaceholderText = NSAttributedString(string: "Enter last name", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
                    
                    lastNameField.attributedPlaceholder = whitePlaceholderText
        }
    }
    
    @IBOutlet weak var emailField: UITextField! {
        didSet {
            let whitePlaceholderText = NSAttributedString(string: "Enter Email", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
                    
                    emailField.attributedPlaceholder = whitePlaceholderText
        }
    }
    
    @IBOutlet weak var passwordField: UITextField! {
        didSet {
            let whitePlaceholderText = NSAttributedString(string: "Enter Password", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
                    
                    passwordField.attributedPlaceholder = whitePlaceholderText
        }
    }
    
    @IBOutlet weak var confirmPasswordField: UITextField! {
        didSet {
            let whitePlaceholderText = NSAttributedString(string: "Re-Enter Password", attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
                    
                    confirmPasswordField.attributedPlaceholder = whitePlaceholderText
        }
    }
  
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var signupBtn: UIButton!
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupElements()
        // Images inside Textfields: -
//        addImgLeft(textField: firstNameField, For: UIImage(named: "Name")!)
//        addImgLeft(textField: lastNameField, For: UIImage(named: "Name")!)
//        addImgLeft(textField: emailField, For: UIImage(named: "Email")!)
//        addImgLeft(textField: passwordField, For: UIImage(named: "Password")!)
//        addImgLeft(textField: confirmPasswordField, For: UIImage(named: "RePassword")!)
        
     //   constraints()
                   
    }
    
    func setupElements() {
        Styling.styleTextField(firstNameField)
        Styling.styleTextField(lastNameField)
        Styling.styleTextField(emailField)
        Styling.styleTextField(passwordField)
        Styling.styleTextField(confirmPasswordField)
    }
    
    func addImgLeft(textField: UITextField, For image: UIImage) {
        let leftImageView = UIImageView(frame: CGRect(x: 0.0, y: 0.0, width: image.size.width/2, height: image.size.height/2))
        leftImageView.image = image
        textField.leftView = leftImageView
        textField.leftViewMode = .always
    }
    
    @available(iOS 13.0, *)
    @IBAction func didSignupTap(_ sender: Any) {
        
        // Validate Textfields: -
        guard let firstName = firstNameField.text,
                  firstName != "",
              let lastName = lastNameField.text,
                  lastName != "",
              let email = emailField.text,
                  email != "",
              let password = passwordField.text,
                  password != "",
              let confirmPassword = confirmPasswordField.text,
                  confirmPassword != ""
        else {
            
            AlertController.showAlert(self, title: "Missing fields", message: "Please fill in all the fields")
            return
        }
        
        // Create the users :-
        Auth.auth().createUser(withEmail: email, password: password) { (result, err) in
            // if there's error
            if err != nil {
                AlertController.showAlert(self, title: "Incorrect", message: err!.localizedDescription)
            }
            else {
                // Successfully User Create, Store first & last Name: -
                let db = Firestore.firestore()
                
                db.collection("users00").addDocument(data: ["firstName": firstName, "lastName": lastName, "email": email, "password": password, "confirm_password": confirmPassword, "uid": result!.user.uid]) { (error) in
                    
                    // Error: -
                    if error != nil {
                        AlertController.showAlert(self, title: "User name could not found", message: error!.localizedDescription)
                    }
                }
            }
        }
            // Perform Segue :-
    //    performSegue(withIdentifier: "SignupToHome", sender: self)
        if #available(iOS 13.0, *) {
            self.transitionTohome()
        } else {
            // Fallback on earlier versions
            print("Error")
        }
    }
    @available(iOS 13.0, *)
    func transitionTohome() {
 
        let homeViewController = storyboard?.instantiateViewController(identifier: Transition.Storyboard.homeVC) as? HomeCollectionViewController
        view.window?.rootViewController = homeViewController
        view.window?.makeKeyAndVisible()
    }

}
